# NovaSalud Farmacia

Sitio web estático de NovaSalud Farmacia.

## Publicar con GitHub Pages

1. Crea un repositorio en GitHub (por ejemplo, `novasalud-web`).
2. Sube `index.html` a la raíz del repositorio.
3. Abre **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`, y guarda.
6. Espera a que GitHub Pages publique el sitio; la dirección aparecerá en esa misma sección.

## Importante

- Esta es una página estática. GitHub Pages no ejecuta Firebase Cloud Functions ni código de servidor.
- Firebase Authentication debe tener autorizado el dominio de GitHub Pages en **Authentication → Settings → Authorized domains**.
- El envío automático de correos personalizados de bienvenida requiere un servicio de correo y una función de servidor; no se debe colocar una contraseña de Gmail ni claves privadas en este HTML.
- Los métodos de pago de esta versión son demostrativos: no procesan pagos ni deben recibir datos bancarios reales.
